# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '2c33e457e81adaf28025712702e1bb8ce99675a77c41127cfb1b56523a32e58cd8b1d62e34e6ca11de7bc03d4df604323a3f3910f9e33e83be57855bcdfd8551'